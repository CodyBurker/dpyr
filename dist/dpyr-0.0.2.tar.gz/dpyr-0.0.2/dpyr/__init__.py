__version__ = '0.0.2'

# Maybe this should explicitly import the classes from dpyr.py
# But for now it's just a wildcard import
from .dpyr import *